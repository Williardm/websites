<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/local.css">
    <title>About - Police Training</title>
</head>
<body>
<section>
    <ul class="nav nav-pills justify-content-center p-4">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="register.php">Register</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="view.php">Registry</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" href="about.php">About</a>
            </li>
          </ul>
          <div class="container">
            <h1 class="text-center">ABOUT US</h1>
            <p>Special Department of police that handles criminal cases and private security. 
              We were formed in 1981 as a result of high criminal cases that took Uganda by storm.
              Our priority is to ensure public safety and assist the over powered UPDF which has been majourly unde staffed in the recent years.
            </p>        
            <h3>CORE VALUES</h3>
            <ol>
              <li>Promote law and order</li>
              <li>Empower women with skills to protect themselves</li>
              <li>Reduce drug trafficing in the country</li>
              <li>To curb domestic violence</li>
              <li>Ensure the country is at peace.</li>
            </ol>
          </div>
      </section>
</body>
</html>