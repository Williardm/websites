<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/local.css">
    <title>Home - Police Training</title>
</head>
<body>
<section>
    <ul class="nav nav-pills justify-content-center p-4">
            <li class="nav-item">
              <a class="nav-link active" href="index.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="register.php">Register</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="view.php">Registry</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="about.php">About</a>
            </li>
          </ul>
          <div class="container">
            <h2 class="text-center">WELCOME TO THE POLICE INDUCTION PROGRAMME</h2>
            <div class="col-10 offset-1">
              <img src="images/police.jpg" class="img-fluid" alt="">
              <p class="pt-3">
                We are an organisation here to defend and protect. Our duty is to make sure Justice is served to eacg and every member of the community.we have the following departments in our orhanisation
              </p>
              <div class="container text-center pt-5">
                <h3>DEPARTMENTS</h3>
                <div class="row my-3">
                  <div class="col-6">
                    <ul>
                      <li>Domestic violence</li>
                      <li>Sexual assult</li>
                      <li>Child abuse</li>
                  </ul>
                  </div>
                  <div class="col-6">
                    <ul>
                      <li>Drug trafficing</li>
                      <li>Human Trafficing</li>
                      <li>Gang activity</li>
                    </ul>
                  </div>
                </div>
              </div>

            </div>
          </div>
      </section>
</body>
</html>