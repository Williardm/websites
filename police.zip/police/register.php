<?php 
    require_once('./config/dbconfig.php'); 
    $db = new operations();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/local.css">
    <title>Register - Police Training</title>
</head>
<body>
    <section>
        <ul class="nav nav-pills justify-content-center p-4">
            <li class="nav-item">
            <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
            <a class="nav-link active" href="register.php">Register</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="view.php">Registry</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="about.php">About</a>
            </li>
        </ul>
    </section>
    <div class="container">
    <h1 class="text-center">REGISTER</h1>
            <p>
            In our efforts to promote security we are faced with a number of hinderances and challenges.the major challenge we have faced is the shortage of labour force which we gave been experiencingfor quite a while  now.
this has obstracted justice as in most cases our officers are out numbered and killed.we turn to you the community and request you to help us maintain law and order.
for any willing aplicants please fill in the form below to join nour training programme
            </p>
        <div class="row">
            <div class="col-lg-6 m-auto">
                <div class="card mt-2 mb-5 bg-dark">
                    <div class="card-header">
                        <h2> Registration Form </h2>
                    </div>
                        <?php $db->Store_Record(); ?>
                        <div class="card-body">
                            <form method="POST">
                                <input type="text" name="First" placeholder=" First Name" class="form-control mb-2" required>
                                <input type="text" name="Last" placeholder=" Last Name" class="form-control mb-2" required>
                                <input type="Email" name="UserEmail" placeholder=" User Email" class="form-control mb-2" required>
                                <input type="text" name="HAddress" placeholder=" Home Address" class="form-control mb-2" required>
                        </div>
                    <div class="card-footer">
                            <button class="btn btn-primary" name="btn_save"> Submit </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>