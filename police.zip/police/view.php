<?php 
    
    require_once('./config/dbconfig.php'); 
    $db = new operations();
    $result=$db->view_record();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/local.css">
    <title>Registry - Police Training</title>
</head>
<body>
    <section>
        <ul class="nav nav-pills justify-content-center p-4">
            <li class="nav-item">
            <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="register.php">Register</a>
            </li>
            <li class="nav-item">
            <a class="nav-link active" href="view.php">Registry</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="about.php">About</a>
            </li>
        </ul>
    </section>
    <div class="container">
    <h1 class="text-center">LIST OF APPLICANTS</h1>
            <p>
        We would like to congratulate the following memebers for making in through the screening phase.
        Training will comence in January . All members are required to report to the Mbuya Military Barracks.
            </p>
        <div class="row">
            <div class="col">
                <div class="card bg-dark text-white mt-2">
                    <div class="card-header">
                        <h2 class="text-center"> Trainees Record </h2>
                    </div>
                    <div class="card-body">
                        <?php
                              $db->display_message(); 
                              $db->display_message();
                        ?>
                        <table class="table table-bordered bg-dark text-white">
                            <tr>
                                <td style="width: 10%"> ID </td>
                                <td style="width: 10%"> First Name </td>
                                <td style="width: 20%"> Last Name </td>
                                <td style="width: 20%"> Email </td>
                                <td style="width: 20%"> Home Address </td>
                                <td style="width: 20" colspan="2">Operations</td>
                            </tr>
                            <tr>
                                <?php 
                                    while($data = mysqli_fetch_assoc($result))
                                    {
                                ?>
                                    <td><?php echo $data['id'] ?></td>
                                    <td><?php echo $data['fname'] ?></td>
                                    <td><?php echo $data['lname'] ?></td>
                                    <td><?php echo $data['email'] ?></td>
                                    <td><?php echo $data['haddress'] ?></td>
                                    <td><a href="edit.php?U_ID=<?php echo $data['id'] ?>" class="btn btn-primary">Edit</a></td>
                                    <td><a href="del.php?D_ID=<?php echo $data['id'] ?>" class="btn btn-danger">Del</a></td>
                            </tr>
                            <?php
                                    }
                                ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>